from setuptools import setup

setup(
    name='send-email',
    version='0.1',
    description='send email using smtplib',
    url='#',
    author='SalarKesha',
    author_email='keshavarzisalar@gmail.com',
    license='MIT',
    packages=['send_email']
)