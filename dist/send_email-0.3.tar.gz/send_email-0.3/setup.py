from setuptools import setup

setup(
    name='send_email',
    version='0.3',
    description='send email using smtplib',
    url='#',
    author='SalarKesha',
    author_email='keshavarzisalar@gmail.com',
    license='MIT',
    packages=['send_email']
)